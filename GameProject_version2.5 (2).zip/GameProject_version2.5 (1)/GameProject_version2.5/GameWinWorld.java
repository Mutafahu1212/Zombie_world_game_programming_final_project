// WARNING: This file is auto-generated and any changes to it will be overwritten
import lang.stride.*;
import java.util.*;
import greenfoot.*;

/**
 * 
 */
public class GameWinWorld extends World
{

    /**
     * Constructor for objects of class GameWinWorld.
     */
    public GameWinWorld()
    {
        super(624, 624, 1);
    }
}
