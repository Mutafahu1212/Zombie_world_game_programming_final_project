import lang.stride.*;
import java.util.*;
import greenfoot.*;

/**
 * 
 */
public class Barrier extends Actor
{
public Barrier() {
// Optional: make it visible or semi-transparent
GreenfootImage img = new GreenfootImage(1500, 69); // width and height
img.setColor(Color.WHITE);
img.fill();
setImage(img);
}
}
    /**
     * Act - do whatever the Barrier wants to do. This method is called whenever the 'Act' or 'Run' button gets pressed in the environment.
     */
    
